
public class Interaction {
    String userId;
    Post post;

    Interaction(String userId, Post post)
    {
        this.userId = userId;
        this.post = post;
    }
}
